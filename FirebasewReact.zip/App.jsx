import React from "react";
import { initializeApp } from "firebase/app";
import { getDocs, getFirestore, collection, addDoc, doc, deleteDoc } from "firebase/firestore";
import { useEffect, useState } from "react";

const firebaseApp = initializeApp({
  apiKey: "AIzaSyAvTstBln0UyZ_ZQAbEW9SMqdklTKBMXBc",
  authDomain: "projeto01-3c603.firebaseapp.com",
  projectId: "projeto01-3c603",
});

export const App = () => {
  const [name, setName] = useState("");   // Listagem dos usuários salvos
  const [email, setEmail] = useState("");
  const [users, setUsers] = useState([]);

const db = getFirestore(firebaseApp);
const userCollectionRef = collection(db, "users");

async function criarUser() {
  const user = await addDoc(userCollectionRef, {
    name,
    email,

  });
  console.log(user);
}

useEffect(() => {
  const getUsers = async () => {
    const data = await getDocs(userCollectionRef);
    setUsers(data.docs.map((doc)=> ({...doc.data(), id: doc.id})));
  };
  getUsers();
}, []);

async function deleteUser(id) {
  const userDoc = doc(db, 'users', id)
  await deleteDoc(userDoc);
}



  return(
    <div>
      <input type="text" placeholder="nome..." value={name} onChange={e => setName(e.target.value) } />
      <input value={email} onChange={e => setEmail(e.target.value)} type="text" placeholder="email..." />
      <button onClick={criarUser}>Criar user</button>
      <ul>
        
          {users.map((user) => {
            return (
              <div key={user.id}>
                <li>{user.name}</li>
                <li>{user.email}</li>
                <button onClick={() => deleteUser(user.id)}>Deletar</button>
              </div>            
          );
        })}
      </ul>
    </div>
    );
};